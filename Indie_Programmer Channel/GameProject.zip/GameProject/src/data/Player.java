package data;

import static helpers.Artist.*;
import helpers.Clock;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class Player implements MouseListener {
	private TileGrid grid;
	private TileType [] types;
	private int index;
	private WaveManager waveManager;
	private ArrayList<Tower > towerList;
	private boolean leftMouseButtonDown;

	public Player(TileGrid grid, WaveManager waveManager){
		this.grid = grid;
		this.types = new TileType[3];
		this.types[0] = TileType.Grass;
		this.types[1] = TileType.Dirt;
		this.types[2] = TileType.Water;
		this.index = 0;
		this.waveManager = waveManager;
		this.towerList = new ArrayList<Tower>();
		this.leftMouseButtonDown = false;


	}
	
	
	public void update(){
		for(Tower t : towerList){
			t.update();
			t.draw();
			//t.updateEnemyList(waveManager.getCurrentWave().getEnemyList());
		}
		// handle mouse input 
		if(Mouse.isButtonDown(0) && !leftMouseButtonDown){
			towerList.add(new TowerCannonBlue(TowerType.cannonBlue, 
					grid.getTile((Mouse.getX() / 64) + 2  , (HEIGHT - Mouse.getY() - 1) / 64)));
			
			
		}

		leftMouseButtonDown = Mouse.isButtonDown(0);

		// handle keyboard input
		while(Keyboard.next()){
			if(Keyboard.getEventKey() == Keyboard.KEY_RIGHT && Keyboard.getEventKeyState()){
				Clock.changeMultiplier(0.2f);	
			}
			if(Keyboard.getEventKey() == Keyboard.KEY_LEFT && Keyboard.getEventKeyState()){
				Clock.changeMultiplier(-0.2f);	
			}
			

		}


	}

	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		System.out.println("Hola");
		System.out.println(e.getX());
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


}
