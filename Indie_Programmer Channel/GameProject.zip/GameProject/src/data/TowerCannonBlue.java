package data;


public class TowerCannonBlue extends Tower {
	
	public TowerCannonBlue(TowerType type , Tile startTile ){
		super(type,startTile);
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
