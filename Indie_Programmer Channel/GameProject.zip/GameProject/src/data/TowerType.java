package data;

import org.newdawn.slick.opengl.Texture;
import static helpers.Artist.*;

public enum TowerType {
	
	CannonRed(new Texture[]{quickLoad("cannonBase"),quickLoad("cannonGun")},10),
	cannonBlue(new Texture []{quickLoad("BlueCannonBase"),quickLoad("BlueCannonGun")}, 30);
	
	Texture [] textures;
	int damage;
	
	TowerType(Texture[] textures,int damage){
		this.textures = textures;
		this.damage = damage;
		
	}
	

}
